a = 1.0

from ..random import foobar
